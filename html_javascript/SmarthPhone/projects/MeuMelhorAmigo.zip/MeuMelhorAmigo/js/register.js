//chamado quando a página é carregada
function ready() {

}